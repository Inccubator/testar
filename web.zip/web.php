<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {   
  // return view('auth.register'); 
   return redirect()->route('register'); // redirect on register on home page
});


Route::get('/FeatureBlog', function ()
 {    
  return view('Design.FeatureBlog');     
 });
Route::get('/privacy-policy', function () {   
  return view('privacy-policy'); 
  
});


/*Route::get('/Department', function () {   
  return view('Design.Department'); 
  
});*/

Route::get('password-reset', 'Auth\PasswordController@showForm')->name('PasswordReset'); //I did not create this controller. it simply displays a view with a form to take the email
Route::post('password-reset', 'Auth\PasswordController@sendPasswordResetToken')->name('PasswordReset');
Route::get('reset-password/{token}', 'Auth\PasswordController@showPasswordResetForm')->where('token', '(.*)');
Route::post('reset-password/{token}', 'Auth\PasswordController@resetPassword')->where('token', '(.*)')->name('ResetPassword');

Auth::routes();
Route::get('/mail_send','PhpmailerController@index')->name('mail_send'); // defult route for testing purpose only
Route::get('/home','HomeController@index')->name('home'); 
Route::get('/test','Users\UserController@test')->name('test');

Route::get('/verify/{token}', 'Auth\RegisterController@verifyUser'); // user verification by email
Route::get('/register-mail-thank-you/{verifytoken}','Auth\RegisterController@RegisterThankYou')->name('RegisterThankYou'); 
Route::post('/resend-mail','Auth\RegisterController@ResendMail')->name('ResendMail'); 

Route::group(['middleware' => ['auth']], function()    
   {
        Route::get('/all-videos','VideoController@VideoSection')->name('videos-section');
        Route::get('/my-videos','VideoController@VideoChannel')->name('my-videos-section');
        Route::get('/video-channel/{UserId}','VideoController@VideoChannel')->name('video-channel');
        Route::post('/load-user-videos-post','VideoController@LoadUserVideoPost')->name('LoadUserVideoPost');
        Route::post('/load-premium-videos-post','VideoController@LoadPremiumVideoPost')->name('LoadPremiumVideoPost');
        Route::post('/load-all-videos-post','VideoController@LoadAllVideoPost')->name('LoadAllVideoPost');
        Route::post('/load-more-featured-videos-post','VideoController@LoadMoreFeaturedVideoPost')->name('LoadMoreFeaturedVideoPost');
        Route::post('/load-most-viwed-videos-post','VideoController@LoadMostViwedVideoPost')->name('LoadMostViwedVideoPost');

        Route::get('/test-page','FrontEndController@TestSection')->name('test-section'); 
        Route::post('/upload-video/','VideoController@UploadVideo')->name('upload-video');
        Route::post('/delete-video/','VideoController@DeleteVideo')->name('delete-video');
        Route::get('/video-detail/{videoid}','VideoController@VideoDetail')->name('videos-detail');
        Route::post('/search-video/','VideoController@GetSearchVideo')->name('search-video');
        Route::get('/search_video/','VideoController@SearchVideoResult')->name('search-video-result');

        Route::get('/premium-videos','VideoController@PremiumVideo')->name('premium-videos');
        Route::get('/connection', 'FrontEndController@Connection');
   	    Route::get('/scroll-page','FrontEndController@scrollPage'); 
        Route::get('/inc-society','FrontEndController@IncSociety')->name('inc-society');  
        Route::get('/inc-tv','FrontEndController@IncTV')->name('inc-tv');  
        //Route::get('/my-blog','FrontEndController@MyBlog')->name('my-blog');  
        //Route::get('/blog-detail','FrontEndController@BlogDetail')->name('blog-detail');  
        Route::get('/blog', 'FrontEndController@Blog')->name('blog');  
      //  Route::get('/all-blog','FrontEndController@AllBlog')->name('all-blog');  
        Route::get('/nomination','FrontEndController@Nomination')->name('nomination');  
        Route::get('/movers-and-shakers-2018','FrontEndController@MoversShakers')->name('movers-and-shakers'); 
       
       
       /* Person PortFolio route start*/
        
        
Route::get('/movers-and-shakers-2018/kenny-mitchell', function () { return view('PersonPortfolio.KennyMitchell');})->name('kenny-mitchell'); 

			Route::get('/movers-and-shakers-2018/brooke-ellis', function () { return view('PersonPortfolio.BrookeEllis');})->name('brooke-ellis');
        
        
        
       		Route::get('/movers-and-shakers-2018/yewande-austin', function () { return view('PersonPortfolio.YewandeAustin');})->name('yewande-austin');
		
		   Route::get('/movers-and-shakers-2018/nikoa-evan-shendricks', function () {   return view('PersonPortfolio.NikoaEvanShendricks'); })->name('nikoa-evan-shendricks');
		
		
		 Route::get('/movers-and-shakers-2018/kim-j-ford', function () 
		  {  return view('PersonPortfolio.KimJFord');  })->name('kim-j-ford');
		  
		  
		  
		   Route::get('/movers-and-shakers-2018/imani-ellis', function () 
		  {  return view('PersonPortfolio.ImaniEllis');  })->name('imani-ellis');
		  
		  
		     Route::get('/movers-and-shakers-2018/tiffanie-stanard', function () 
		  {  return view('PersonPortfolio.TiffanieStanard');  })->name('tiffanie-stanard');
		  
		  
		  
		   Route::get('/movers-and-shakers-2018/danny-hastings', function () 
		  {  return view('PersonPortfolio.DannyHastings');  })->name('danny-hastings');
		  
		  
		   Route::get('/movers-and-shakers-2018/Julian-Riley', function () 
		  {  return view('PersonPortfolio.JulianRiley');  })->name('Julian-Riley');
		  
		   
		  Route::get('/movers-and-shakers-2018/jasmine-johnson', function () 
		  {  return view('PersonPortfolio.JasmineJohnson');  })->name('jasmine-johnson');
		  
		 
		   Route::get('/movers-and-shakers-2018/detavio-samuels', function () 
		  {  return view('PersonPortfolio.DetavioSamuels');  })->name('detavio-samuels');
		  
		   Route::get('/movers-and-shakers-2018/natalia-allen', function () 
		  {  return view('PersonPortfolio.NataliaAllen');  })->name('natalia-allen');
		  
		  
		   Route::get('/movers-and-shakers-2018/rodney-williams', function () 
		  {  return view('PersonPortfolio.RodneyWilliams');  })->name('rodney-williams');
		  
		  Route::get('/movers-and-shakers-2018/cynthia-sepulveda', function () 
		  {  return view('PersonPortfolio.CynthiaSepulveda');  })->name('cynthia-sepulveda');
		  
		 
		  Route::get('/movers-and-shakers-2018/charles-chuck-wimbley', function () 
		  {  return view('PersonPortfolio.CharlesChuckWimbley');  })->name('charles-chuck-wimbley');
		  
		  		  
		  Route::get('/movers-and-shakers-2018/brennan-williams', function () 
		  {  return view('PersonPortfolio.BrennanWilliams');  })->name('brennan-williams');
		  
		  Route::get('/movers-and-shakers-2018/brandon-frame', function () 
		  {  return view('PersonPortfolio.BrandonFrame');  })->name('brandon-frame');
		  
		  
		  Route::get('/movers-and-shakers-2018/adeola-adeJobi', function () 
		  {  return view('PersonPortfolio.AdeolaAdeJobi');  })->name('adeola-adeJobi');
		  
		   Route::get('/movers-and-shakers-2018/vivian-odior', function () 
		  {  return view('PersonPortfolio.VivianOdior');  })->name('vivian-odior');
		 
		    Route::get('/movers-and-shakers-2018/rashad-howard', function () 
		  {  return view('PersonPortfolio.RashadHoward');  })->name('rashad-howard');
		  
		    Route::get('/movers-and-shakers-2018/faith-taylor', function () 
		  {  return view('PersonPortfolio.FaithTaylor');  })->name('faith-taylor');
		  
		    Route::get('/movers-and-shakers-2018/andre-huestonma-mack', function () 
		  {  return view('PersonPortfolio.AndreHuestonmaMack');  })->name('andre-huestonma-mack');
		  
		Route::get('/upload-video-page', function () 
		  {  
		  return view('Videos.UploadVideoPage');
		  })->name('upload-video-page');
	
		
		
/* Person PortFolio route end*/

        
        
        
        
   /* Route::group(['middleware' => ['auth']], function()    
      {  
    
		Route::get('/movers-and-shakers-2018/Yewande-austin', function () 
		{   
		  return view('PersonPortfolio.YewandeAustin'); 
		
		});
});*/ 

 
    
    
    
        
        /* department*/
        
      
 		
 		Route::get('/nv-magazine/feature-blog', function ()
                  {   
 						 return view('Design.NvMagzineFeatureBlog');   
  
 				  });	
 				  
 				  
 				  Route::get('/country-over-party/feature-blog', function ()
                  {   
 						 return view('Design.CountryFeatureBlog');   
  
 				  });	  
 				  
 			  
 	  /*  Route::get('/upscale/department', function ()
                  {   
 						 return view('Design.UpScaleDepartment'); 
  
 				  });*/	
 				  // Route::get('/upscale/department', function ()
       //            {   
 						//  //return view('Design.UpScaleDepartment'); 
       //            	echo "Comming soon";
  
 				  // });
 				  //  Route::get('/country-over-party/department', function ()
       //            {   
 						
 						//  return view('Design.CountryDepartment');
  
 				  // });		  
        
       /* department*/
   }); 
   
  
  Route::group(['middleware' => ['auth'],'namespace'=>'Company'], function()
        {
         Route::get('company/{companyname?}/{companyid?}','CompanyController@CompanyView')->name('company-page');
         Route::post('add/company/detail','CompanyController@PostCompany')->name('CompanyPost');
         Route::post('company/follow/','CompanyController@AddCompanyFollow')->name('AddCompanyFollow');
         
         
        });
 
  Route::group(['middleware' => ['auth']], function()
        {
          Route::get('notification','NotificationController@Notification')->name('notification-page'); 

          Route::post('birthday/reminder','NotificationController@SetReminder')->name('set-reminder');

Route::get('notification/post-details/{PostId}','NotificationController@NotificationPostDetails')->name('NotificationPostDetails');


 Route::get('notification/remove/{PostId}/{NotificationType}','NotificationController@NotificationRemove')->name('NotificationRemove');
 Route::post('multiple_notification_remove','NotificationController@MultipleNotificationRemove')->name('MultipleNotificationRemove');
    });  

Route::group(['middleware' => ['auth'],'namespace'=>'Post'], function()
{
    Route::get('/{channelslug}/department','PostController@Department')->name('nv-magazine-department'); 
    Route::get('/{channelslug}/department/{posttitle}/{postid}','PostController@PostDetails')->name('department-post-details');


Route::post('/upload_feed_post','PostController@SetUserPost')->name('set-user-feed-post');
Route::post('/get_feed_post','PostController@GetUserPost')->name('get-user-feed-post'); // get feed post by ajax on userprofile page
Route::post('/load_hash_tag','PostController@LoadUserProfileHashTag')->name('LoadUserProfileHashTag'); // get Hash Tag by ajax on userprofile page
Route::post('/share_feed_post','SharePostController@ShareFeedPost')->name('share-feed-post');


Route::post('/get_post_link_preview','PostController@GetPostLinkPreview')->name('get-post-link-preview');
Route::get('/{channelslug}/featured-article/{posttitle}/{postid}','PostController@FeaturedArticle')->name('featured-article');// ravindra
Route::get('/{channelslug}/featured-blog','PostController@FeaturedBlog')->name('featured-blogs');// ravindra
Route::get('/{channelslug}/featured-blog/{posttitle}/{postid}','PostController@PostDetails')->name('featured-blog');
// ravindra
Route::post('/post/comments','PostController@AddPostComments')->name('add-post-comments');
Route::post('/comment/likes','PostController@AddCommentLikes')->name('add-comment-likes');
Route::get('/post/delete/{PostID}','PostController@DeleteUserPost')->name('user-post-delete');
Route::post('/post/like-dislike','PostController@AddPostLikes')->name('add-post-like-dislike');

Route::get('/nv-magazine/department1','PostController@Department1');

//fead-post-view for report as spam
Route::get('/feed-post-view/{postid}/{usertype?}','PostController@FeedPostView')->name('feed-post-view');

// user DeleteLatestPicsPostImage
Route::get('/view-more/latest-pics/slider/{PostId}','PostController@SliderLatestPics');

});  

Route::group(['middleware' => ['auth'],'namespace'=>'Group'], function(){

Route::post('/group/create','GroupController@AddGroup')->name('group-create'); 
Route::get('/group/popup/{GroupId}','GroupController@GroupPopup');
Route::get('/group/invite-member-search','GroupController@InviteMemberSearch');
Route::get('/group/{GroupType}','GroupController@GetGroup')->name('group-type'); 
Route::post('/group/join','GroupController@JoinGroup')->name('group-join'); 
Route::get('/group/members/{GroupId}','GroupController@GetGroupMembers')->name('group-members');
Route::get('/group/delete/{GroupId}','GroupController@DeleteGroup');
Route::post('/group/invite-members','GroupController@GroupInviteMembers')->name('GroupInviteMembers');
Route::post('/group/cancel-group-request','GroupController@CancelGroupRequest')->name('CancelGroupRequest');
});

Route::group(['middleware' => ['auth'],'namespace'=>'Event'], function(){

Route::post('/event/create','EventController@AddEvent')->name('event-create'); 
Route::get('/event/popup/{EventId}','EventController@EventPopup'); 
Route::get('/event/list','EventController@GetEvent')->name('event-list'); 
Route::post('/event/join','EventController@JoinEvent')->name('event-join'); 
Route::get('/event/members/{EventId}','EventController@GetEventMembers')->name('event-members');
Route::get('/event/delete/{EventId}','EventController@DeleteEvent');
Route::post('/event/cancel-group-request','EventController@CancelEventRequest')->name('CancelEventRequest');
});

Route::group(['namespace'=>'Admin'], function()   
   {
	Route::get('/admin/home','AdminHomeController@index')->name('admin-home');  
	Route::get('/admin/post/{posttype}/{channelslug}/{channelpostslug?}','AdminChannelController@GetStories')->name('admin-content-channel');  

	Route::get('/admin/edit/story/{postid}','AdminChannelController@ShowStories')->name('admin-edit-story'); 
	Route::post('/admin/edit/story/{postid}','AdminChannelController@SetPost')->name('admin-edit-story');  

	Route::get('/admin/add/story/{posttype}/{channelslug}/{channelpostslug?}','AdminChannelController@AddPost')->name('admin-add-post');
	Route::post('/admin/add/story','AdminChannelController@SetPost')->name('admin-set-post');
	Route::get('/admin/edit/story/{posttype}/{channelslug}/{channelpostslug}/{postid}','AdminChannelController@AddPost')->name('admin-edit-post');
    Route::get('/admin/edit/story/delete/{postimageid}','AdminChannelController@PostImagesDelete')->name('admin-post-images-delete');
	Route::get('/admin/delete/story/{postid}','AdminChannelController@DeletePost')->name('admin-delete-post');
  Route::get('/admin/delete/story1/{postid}','AdminChannelController@DeletePost1')->name('admin-delete-post1');
    Route::get('/admin/stories/{postid}','AdminChannelController@StoriesViewDetails')->name('stories-view-details');
	
	Route::get('/admin/users','AdminUserController@GetUsers')->name('admin-users');

	Route::get('/admin/newsletter','AdminUserController@Newsletter')->name('admin-newsletter');
	Route::post('/admin/newsletter','AdminUserController@Newsletter')->name('admin-newsletter');

    Route::get('/admin/business-card-of-the-week','AdminUserController@BusinessCardofTheWeekAjax')->name('BusinessCardofTheWeekAjax');
    Route::post('/admin/user-status-change','AdminUserController@UserStatusChange')->name('user-status-change');
    Route::get('/admin/user-view-profile/{userId}','AdminUserController@UserViewProfile')->name('user-view-profile');

    Route::get('/admin/analytics','AdminAnalyticController@GetAnalytics')->name('admin-analytics');
    Route::get('/admin/blog/analytics','AdminAnalyticController@GetBlogAnalytics')->name('admin-blog-analytics');
    Route::get('/admin/user/analytics','AdminAnalyticController@GetUserAnalytics')->name('admin-user-analytics');
    Route::post('/admin/post/trending','AdminChannelController@MakePostTrending')->name('make-post-trending');

    //get post user mark as spam
    Route::get('/admin/post/report','AdminPostController@PostReportAsSpam')->name('admin-post-report');

    //get user blog Pending or Submit To Iccubator
    Route::get('/admin/story/status','AdminPostController@UserStoryStatus')->name('user-story-status');

    //get user video Pending or Submit To Iccubator
    Route::get('/admin/video/status','AdminPostController@UserVideoStatus')->name('user-my-video-status');

    //get user featured blog Pending or Submit To Iccubator
    Route::get('/admin/featured-story/status','AdminPostController@UserStoryStatus')->name('user-featured-story-status');

    //get user featured blog Pending or Submit To Iccubator
    Route::get('/admin/more-featured-story/status','AdminPostController@UserStoryStatus')->name('user-more-featured-story-status');

    //get user blog Pending or Submit To Iccubator approved
    Route::get('/admin/story/approved/{PostId}/{PostStatus}','AdminPostController@AdminStoryApproved')->name('story-approved');

    //get user video Pending or Submit To Iccubator approved
    Route::get('/admin/video/approved/{PostId}/{PostStatus}','AdminPostController@AdminVideoApproved')->name('my-video-approved');

    //get user blog report
    Route::get('/admin/story/report','AdminPostController@UserStoryReport')->name('user-report-story');
  });




//Route Group For Users
Route::group(['middleware' => ['auth'],'namespace'=>'Users'], function()   
   {

   // GetUser profile
   Route::get('/profile/{username}/{userid}/{channelslug?}','UserController@ViewProfile')->middleware('checkuserstatus')->where('userid','[0-9]+')->name('viewprofile');

   Route::get('/setting','UserController@setting')->name('setting');
 
   Route::get('search/showhashpost/','UserController@ViewProfile')->name('showhashpost');
   
   
 
   
   
   
  Route::get('/group/post/{groupid}/','UserController@ViewProfile')->middleware('checkuserstatus')->where('groupid','[0-9]+')->name('group-post');  
   
   // GetGroup Post
   
   
     Route::get('/event/post/{eventid}/','UserController@ViewProfile')->middleware('checkuserstatus')->where('eventid','[0-9]+')->name('event-post');  
     // get event post
   
   
   
   
   
   Route::get('/group/{username}/{userid}/{groupid}','UserController@ViewProfile')->middleware('checkuserstatus')->where('userid','[0-9]+')->name('viewgroupprofile');
   
   
   	  Route::get('profile/user-detail/{username}/{userid}','UserController@UserProfileDetail')->name('user-profile-detail');

      Route::get('profile/view-more/common-delete','UserController@CommonDelete')->name('CommonDelete');

      // user ask for recommendation
   Route::post('profile/view-more/ask-for-recommendation','UserController@AddAskForRecommendation')->name('AddAskForRecommendation');

   // user add recommendation
   Route::post('profile/view-more/add-recommendation','UserController@AddRecommendation')->name('AddRecommendation');
   
   
   
   // EditUser profile
   Route::post('/profile','UserController@EditProfile')->name('editprofile'); 
  
    // SearchUser profile
    Route::get('/search','UserController@SearchUser')->name('searchuser');

    // user profile post block
    Route::post('/profile_delete_post','UserController@ProfileDeletePost')->name('ProfileDeletePost');

    // user ReportAsSpam
    Route::post('/report-as-spam','UserController@UserReportAsSpam')->name('ReportAsSpam');

    // user report  story
    Route::get('/report_story_ajax/{PostId}','UserController@ReportStoryAjax');

    // user GetModalContent
    Route::get('/user/get-modal-content','UserController@GetModalContent')->name('GetModalContent');

    // user add academic path
    Route::post('/user/add-academic-path','UserController@AddAcademicPath')->name('AddAcademicPath');

    // user add career journey
    Route::post('/user/add-career-journey','UserController@AddCareerJourney')->name('AddCareerJourney');

    // user add accolades as a post
    Route::post('/user/accolades','UserController@AddAccolades')->name('AddAccolades');

    // user AddMediaGallery
    Route::post('/user/media-gellary','UserController@AddMediaGallery')->name('AddMediaGallery');

    // user add give back
    Route::post('/user/give-back','UserController@AddGiveBack')->name('AddGiveBack');
    
    Route::post('/user/ability','UserController@AddAbility')->name('AddAbility');
    Route::post('/ability/likes','UserController@AddAbilityLike')->name('AbilityLikes');

    Route::post('/LoadRecommendationReceived','UserController@LoadRecommendationReceived')->name('LoadRecommendationReceived'); // Load Recommendation Received by ajax on user profile details page

    Route::post('/LoadRecommendationGiven','UserController@LoadRecommendationGiven')->name('LoadRecommendationGiven'); // Load Recommendation Given by ajax on user profile details page

    Route::post('/reset-your-password','UserController@ResetYourPassword')->name('ResetYourPassword');//Reset Your Password by user
    
    // user account suspended
    Route::get('/user/account/suspended','UserController@AccountSuspended')->name('AccountSuspended');

    // Another User Block UnBlock
    Route::get('/user/another/user-block-unblock','UserController@AnotherUserBlockUnBlock')->name('AnotherUserBlockUnBlock');

   }); 

   Route::get('/admin/search','Users\UserController@SearchUser')->name('adminsearchuser');
   Route::group(['middleware' => ['auth'],'namespace'=>'Card'], function()   
   {
   	 
   	 // RequestCard on edit
   	 Route::post('/request_card','CardController@RequestCard')->name('request_card'); 
     
     // CancelCard on edit
     Route::post('/cancel_card','CardController@CancelCard')->name('cancel_card'); 
     
     // CancelMultiple card
     Route::post('/cancel_card1','CardController@CancelCard1')->name('cancel_card1'); 
     // AcceptCard
     Route::post('/accept_card','CardController@AcceptCard')->name('accept_card'); 
     
     
      // Rolodex
      Route::get('/card-holder/{username}/{userid}','CardController@GetConnectedCard')->name('card-holder'); 
      Route::get('/mutual-card-holder/{username}/{userid}','CardController@GetConnectedMutualCard')->name('mutual-card-holder');
      Route::post('/card_category_create','CardController@CardCategoryCreate')->name('card_category_create');
      Route::get('/card_category_delete/{card_category_id}','CardController@CardCategoryDelete')->name('card_category_delete');
      Route::post('/card_category_move_to_folder','CardController@CardCategoryMoveToFolderAjax')->name('card_category_move_to_folder');

      Route::get('/card_category_card_lists_ajax/{card_category_id}','CardController@CardCategoryCardListsAjax')->name('card_category_card_lists_ajax');

      Route::get('/delete_card_from_folder_ajax/{card_id}','CardController@DeleteCardFromFolderAjax')->name('delete_card_from_folder_ajax');

      Route::get('/user_card_status_change','CardController@UserCardStatusChange')->name('UserCardStatusChange');
   }); 
   
    Route::group(['middleware' => ['auth'],'namespace'=>'Message'], function()   
   {
  	 Route::post('/user_send_msg','MessageController@UserSendMessage')->name('user_send_msg');  
  	 
  	 Route::post('/get_chat_msg','MessageController@GetUserchatMsg')->name('get_chat_msg'); 

  	 Route::get('/delete_chat_msg/{UserId}','MessageController@DeleteUserchatMsg'); 
  	 
  	 Route::post('/set_user_chat_msg','MessageController@SetUserChatMessage')->name('set_user_chat_msg'); 
  	 
  	  
   	 
   	 
   	}); 
   
   // NOTES
    Route::group(['middleware' => ['auth'],'namespace'=>'Notes'], function()   
   {
  	 Route::post('/user_add_note','NotesController@AddNoteUser')->name('user_add_note');  
   	 
   	 
   	}); 



/* ravindra route start*/
Route::group(['middleware' => ['auth']], function() 
{
Route::get('/user/{channelslug}/{postslug}','IncTVController@GetIncTv')->name('inc-tv-user');
//Route::get('/blog-detail/{PostId}','IncTVController@BlogDetail')->name('blog-detail');
Route::get('/user/{PostSlug}/{PostTitle}/{PostId}','IncTVController@BlogDetail')->name('post-detail');

Route::get('/post/previousnext/{PostId}/{PreviousNext}','IncTVController@BlogDetailPreviousNext')->name('post-previous-next');

});

Route::group(['middleware' => ['auth']], function() 
{
Route::get('/profile/{channelslug}/{postslug}','IncSocietyController@GetIncSociety')->name('inc-society-user');
});

Route::group(['middleware' => ['auth']], function() 
{

Route::get('/blog/write-blog','BlogController@addBlog')->name('write-blog');

Route::post('/blog/write-blog','BlogController@addBlog')->name('write-blog');

Route::get('/blog/write-blog/{blogid}','BlogController@addBlog')->name('write-blog-edit');

Route::get('/blog/{blogTitle}/{blogId}','BlogController@blogDetails')->name('blog-details')->where('blogTitle', '(.*)');

Route::get('/blog/{BlogPageType}','BlogController@BlogList')->name('blog-list')->where('BlogPageType', 'my-blog|all-blog');

Route::get('blogshare','BlogController@BlogShare')->name('blogshare');

Route::post('/blog/load-blog-post','BlogController@LoadBlogPost')->name('LoadBlogPost');

Route::post('/blog/load-all-blog-post','BlogController@LoadAllBlogPost')->name('LoadAllBlogPost');

Route::post('/blog/load-more-featured-blog-post','BlogController@LoadMoreFeaturedBlogPost')->name('LoadMoreFeaturedBlogPost');

Route::post('/blog/load-most-viwed-post','BlogController@LoadMostViwedPost')->name('LoadMostViwedPost');


Route::get('/blog/submit-to-featured-stories','BlogController@addBlog')->name('submit-to-featured-stories');

Route::post('/blog/submit-to-featured-stories','BlogController@addBlog')->name('submit-to-featured-stories');

Route::get('/blog/submit-to-more-featured-stories','BlogController@addBlog')->name('submit-to-more-featured-stories');

Route::post('/blog/submit-to-more-featured-stories','BlogController@addBlog')->name('submit-to-more-featured-stories');

Route::post('/blog/post_send_mail_form','BlogController@PostDetailSendMailForm')->name('PostDetailSendMailForm');

//{channelslug}
});

Route::group(['middleware' => ['auth'],'namespace'=>'FollowFollowing'], function(){
// Follow User Other
Route::post('/follow/add','FollowFollowingController@AddFollow')->name('FollowAdd');


// Get User Followers and Followings
Route::get('/user/followers','FollowFollowingController@GetFollowersAndFollowing')->name('user-followers-followings'); 
});
Route::group(['middleware' => ['auth'],'namespace'=>'Comment'], function()
{
Route::post('/comment/reply','CommentController@AddCommentReply')->name('add-comment-reply');
Route::post('/reply/likes','CommentController@AddCommentReplyLikes')->name('add-comment-reply-like');

// own post any comment delete
Route::post('/post-comment-delete','CommentController@PostCommentDelete')->name('PostCommentDelete');

// own reply on comment delete
  Route::post('/comment-reply-delete','CommentController@CommentReplyDelete')->name('CommentReplyDelete');

});

//footer link start
Route::get('/about','FrontEndController@About')->name('About');
Route::get('/vision','FrontEndController@Vision')->name('Vision');
Route::get('/mission','FrontEndController@Mission')->name('Mission');
Route::get('/who-we-are','FrontEndController@WhoWeAre')->name('Who-We-Are');

Route::get('/need-help','FrontEndController@NeedHelp')->name('Need-Help');
Route::get('/faqs','FrontEndController@FAQs')->name('FAQs');
Route::get('/report-abuse','FrontEndController@ReportAbuse')->name('Report-Abuse');
Route::get('/report-a-problem','FrontEndController@ReportAProblem')->name('Report-A-Problem');

Route::get('/manage-your-accounts','FrontEndController@ManageYourAccounts')->name('Manage-Your-Accounts');
Route::get('/reset-your-password','FrontEndController@ResetYourPassword')->name('Reset-Your-Password');
Route::get('/change-your-email-address','FrontEndController@ChangeYourEmailAddress')->name('Change-Your-Email-Address');
Route::get('/open-a-content-channel-subscription','FrontEndController@OpenAContentChannelSubscription')->name('Open-A-Content-Channel-Subscription');
Route::get('/open-a-premium-video-channel-subscriptionl','FrontEndController@OpenAPremiumVideoChannelSubscriptionl')->name('Open-A-Premium-Video-Channel-Subscriptionl');
Route::get('/open-a-premium-video-channel','FrontEndController@OpenAPremiumVideoChannel')->name('Open-A-Premium-Video-Channel');
Route::get('/manage-or-close-your-accounts','FrontEndController@ManageOrCloseYourAccounts')->name('Manage-Or-Close-Your-Accounts');

Route::get('/newsroom','FrontEndController@Newsroom')->name('Newsroom');
Route::get('/submit-story-ideas','FrontEndController@SubmitStoryIdeas')->name('Submit-Story-Ideas');
Route::get('/get-paid-to-write','FrontEndController@GetPaidToWrite')->name('Get-Paid-To-Write');
Route::get('/get-paid-to-capture-video-and-images','FrontEndController@GetPaidToCaptureVideoAndImages')->name('Get-Paid-To-Capture-Video-And-Images');

Route::get('/privacy-and-terms','FrontEndController@PrivacyAndTerms')->name('Privacy-And-Terms');
Route::get('/your-agreement','FrontEndController@YourAgreement')->name('Your-Agreement');
Route::get('/data-policy','FrontEndController@DataPolicy')->name('Data-Policy');
Route::get('/code-of-conduct','FrontEndController@CodeOfConduct')->name('Code-of-Conduct');
Route::get('/manage-your-privacy-settings','FrontEndController@ManageYourPrivacySettings')->name('Manage-Your-Privacy-Settings');

Route::get('/advertising','FrontEndController@Advertising')->name('Advertising');
Route::get('/media-kit','FrontEndController@MediaKit')->name('Media-Kit');
Route::get('/native-advertising','FrontEndController@NativeAdvertising')->name('Native-Advertising');
Route::get('/video-programming','FrontEndController@VideoProgramming')->name('Video-Programming');
Route::get('/display-advertising','FrontEndController@DisplayAdvertising')->name('Display-Advertising');
Route::get('/custom-sponsorships','FrontEndController@CustomSponsorships')->name('Custom-Sponsorships');
Route::get('/influencer-partnerships','FrontEndController@InfluencerPartnerships')->name('Influencer-Partnerships');

Route::get('/community-support','FrontEndController@CommunitySupport')->name('Community-Support');
Route::get('/scholarship-business-fund','FrontEndController@ScholarshipBusinessFund')->name('Scholarship-Business-Fund');
Route::get('/download-the-inccubator-app','FrontEndController@DownloadTheInccubatorApp')->name('Download-The-Inccubator-App');
Route::get('/contact-us','FrontEndController@ContactUs')->name('Contact-Us');
Route::get('/baby-baller-investment-fund','FrontEndController@BabyBallerInvestmentFund')->name('baby-baller-investment-fund');


Route::get('supporters', function (){ return view('Supporters');})->name('Supporters');

//footer link end
/*ravindra route end*/